#!/usr/bin/env bash
# ============================================================
#   CBE TIMETABLING SYSTEM  -  macOS / Linux launcher
#   In Terminal:  bash Start-Mac-Linux.sh
# ============================================================
cd "$(dirname "$0")" || exit 1
echo
echo "  Starting the CBE Timetabling System..."
echo

if ! command -v python3 >/dev/null 2>&1; then
  echo "  [!] Python 3 is not installed. Install Python 3.10+ from https://www.python.org/downloads/"
  exit 1
fi

if [ ! -d ".venv" ]; then
  echo "  First run: setting up (this happens only once)..."
  python3 -m venv .venv
  source .venv/bin/activate
  python -m pip install --upgrade pip >/dev/null
  pip install -r requirements.txt
else
  source .venv/bin/activate
fi

echo
python app.py
