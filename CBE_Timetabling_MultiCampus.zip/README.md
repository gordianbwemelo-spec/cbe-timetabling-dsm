# CBE Timetabling System — Multi-Campus Edition

A shared web system where **any campus** creates its own space and feeds in its own
data, then builds and edits a rule-checked timetable. Each campus's data is kept
completely separate; the central office can switch between campuses from one address.

## What each campus does
1. **Open the website** and click **Add campus** (or pick an existing one).
2. Go to the **Data** tab and enter (or upload by CSV) that campus's:
   - **Premises** — the sites/buildings. Tick *evening allowed* where classes may run
     after 17:00, and set teaching days per week. (Nothing is hard-coded, so a campus
     with only one premises, or several, is fine.)
   - **Venues** — rooms with capacity, which premises they belong to, and whether a room
     is a **postgraduate room** (used to keep NTA9 classes in the right rooms).
   - **Instructors & qualifications**, **Teaching capability** (who can teach what),
     **Curriculum** (modules per programme; the **NTA level fills in automatically from
     the module code** — e.g. ACT**04**101 → NTA4, ACU**07**309 → NTA7 Year 2), and
     **Enrolment** numbers.
3. Open the **Rules** tab to review the standard rules and add any campus-specific ones.
4. Use **Generate** to build the timetable, then edit freely — every edit is rule-checked.

## The rules (kept as sensible defaults, adjustable per campus)
- No instructor / room / cohort double-booking.
- Room capacity (+ small tolerance).
- **Evening classes** only where the premises allows them.
- Labs/smart rooms reserved for hands-on IT modules.
- **Postgraduate (NTA9)** classes use postgraduate rooms (only if the campus defines any)
  and run evenings/Saturday.
- Load limits per lecturer (modules, daytime hours, evening hours).
- Plus any free-text rules a campus adds on the Rules tab.

## Run it locally
```
pip install -r requirements.txt
python app.py
```
Then open the printed address. Campus data is stored on your computer (off any
cloud-synced folder). Override the location with the `CBE_DATA` environment variable.

## Put it online (one address for all campuses)
Deploy with the included `render.yaml` (see the comments in that file). Every campus's
database lives on the persistent disk, so data survives restarts.
