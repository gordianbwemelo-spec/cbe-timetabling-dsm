@echo off
REM ============================================================
REM   CBE TIMETABLING SYSTEM  -  Windows launcher
REM   Double-click this file to start the system.
REM ============================================================
cd /d "%~dp0"
echo.
echo   Starting the CBE Timetabling System...
echo.

where python >nul 2>nul
if errorlevel 1 (
  echo   [!] Python is not installed.
  echo       Please install Python 3.10+ from https://www.python.org/downloads/
  echo       During install, tick "Add Python to PATH".
  pause
  exit /b 1
)

if not exist ".venv" (
  echo   First run: setting up ^(this happens only once^)...
  python -m venv .venv
  call ".venv\Scripts\activate.bat"
  python -m pip install --upgrade pip >nul
  pip install -r requirements.txt
) else (
  call ".venv\Scripts\activate.bat"
)

echo.
echo   Opening the system in your web browser...
start "" http://localhost:5000
python app.py
pause
